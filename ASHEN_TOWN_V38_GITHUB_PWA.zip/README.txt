ASHEN TOWN V37 — GitHub Pages / Android package

СОДЕРЖИМОЕ
- index.html — игра.
- manifest.webmanifest — настройки PWA.
- sw.js — кэш для офлайн-запуска.
- icons/ — иконки приложения.

GITHUB
1. Откройте репозиторий https://github.com/d80ik4ll-max/ashen-town
2. Загрузите ВСЕ файлы и папку из этого архива в корень репозитория (не загружайте сам ZIP вместо распаковки).
3. В Settings → Pages выберите Deploy from a branch, ветку main и папку /(root), затем Save.
4. Дождитесь публикации. Адрес проекта обычно: https://d80ik4ll-max.github.io/ashen-town/

ANDROID
1. Откройте https://pwabuilder.com/
2. Вставьте опубликованный HTTPS-адрес GitHub Pages.
3. Выберите Package for stores → Android → Generate Package. Для установки на телефон скачайте APK; для Google Play обычно нужен AAB и настройка подписи/asset links.

Важно: PWABuilder принимает опубликованный PWA-сайт по HTTPS, а не ZIP с исходниками напрямую.
