ASHEN TOWN V44 - mobile horror game PWA package.
Open index.html through a local web server or install as a PWA.
The Android APK workflow can unpack this ZIP into the app assets folder.
